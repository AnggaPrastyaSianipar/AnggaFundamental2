import './styles/style.css';
import './components/header';
import './components/note_form';
import './components/note_list';
import Swal from 'sweetalert2';
import gsap from 'gsap';

function toggleLoader(isVisible = true) {
  const loader = document.getElementById('loading');
  if (loader) {
    loader.style.display = isVisible ? 'flex' : 'none';
  }
}

async function fetchData(url, method = 'GET', body = null) {
  try {
    toggleLoader(true);
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);
    const result = await response.json();
    if (response.ok) {
      return result.data || [];
    } else {
      throw new Error(result.message || 'Request failed');
    }
  } catch (error) {
    Swal.fire('Error', error.message || 'Something went wrong', 'error');
    return [];
  } finally {
    toggleLoader(false);
  }
}

export async function getMainNotes() {
  return fetchData('https://notes-api.dicoding.dev/v2/notes');
}

export async function getArchivedNotes() {
  return fetchData('https://notes-api.dicoding.dev/v2/notes/archived');
}

export async function addNoteNew(note) {
  const result = await fetchData(
    'https://notes-api.dicoding.dev/v2/notes',
    'POST',
    note
  );
  if (result) {
    Swal.fire('Success', 'Note successfully added', 'success');
  } else {
    Swal.fire('Error', 'Failed to add note', 'error');
  }
  return result;
}

export async function deleteNote(noteId) {
  const result = await fetchData(
    `https://notes-api.dicoding.dev/v2/notes/${noteId}`,
    'DELETE'
  );
  if (result) {
    Swal.fire('Deleted', 'Note successfully deleted', 'success');
  } else {
    Swal.fire('Error', 'Failed to delete note', 'error');
  }
  return result;
}

export async function archiveNoteInApi(noteId) {
  const result = await fetchData(
    `https://notes-api.dicoding.dev/v2/notes/${noteId}/archive`,
    'POST'
  );
  if (result) {
    Swal.fire('Archived', 'Note successfully archived', 'success');
  } else {
    Swal.fire('Error', 'Failed to archive note', 'error');
  }
  return result;
}

export async function unarchiveNoteInApi(noteId) {
  const result = await fetchData(
    `https://notes-api.dicoding.dev/v2/notes/${noteId}/unarchive`,
    'POST'
  );
  if (result) {
    Swal.fire('Unarchived', 'Note successfully restored', 'success');
  } else {
    Swal.fire('Error', 'Failed to unarchive note', 'error');
  }
  return result;
}

document.addEventListener('DOMContentLoaded', () => {
  const noteForm = document.querySelector('note-form');
  const noteList = document.querySelector('note-list');

  noteForm.addEventListener('add-note', async (event) => {
    const { title, body } = event.detail;
    const newNote = await addNoteNew({ title, body });

    if (newNote) {
      noteList.updateNotes();
    }
  });

  noteList.addEventListener('delete-note', async (event) => {
    const { id } = event.detail;
    const success = await deleteNote(id);
    if (success) {
      noteList.updateNotes();
    }
  });

  noteList.addEventListener('archive-note', async (event) => {
    const { id } = event.detail;
    const success = await archiveNoteInApi(id);
    if (success) {
      const noteItem = noteList.shadowRoot.querySelector(
        `note-item[data-id="${id}"]`
      );
      gsap.to(noteItem, {
        duration: 0.6,
        opacity: 0,
        y: 20,
        ease: 'power2.in',
        onComplete: () => {
          noteList.updateNotes();
        },
      });
    }
  });

  noteList.addEventListener('unarchive-note', async (event) => {
    const { id } = event.detail;
    const success = await unarchiveNoteInApi(id);
    if (success) {
      const noteItem = noteList.shadowRoot.querySelector(
        `note-item[data-id="${id}"]`
      );
      gsap.to(noteItem, {
        duration: 0.6,
        opacity: 0,
        y: -90,
        ease: 'power2.in',
        onComplete: () => {
          noteList.updateNotes();
        },
      });
    }
  });

  noteList.updateNotes();
});
