import { addNoteNew } from '../main';

class NoteForm extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.shadowRoot.innerHTML = `
 <style>
    form {
        background: rgba(153, 153, 153, 0.8); /* Latar belakang dengan efek transparan */
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* Efek cahaya lebih kuat */
        margin: 50px auto;
        max-width: 500px;
    }

    label {
        margin: 5px;
        font-weight: bold;
    }

    input, textarea {
        width: 90%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 4px;
        transition: border-color 0.3s, box-shadow 0.3s; /* Tambahkan transisi untuk efek shadow */
    }

    input:focus, textarea:focus {
        border-color: #987D9A; /* Warna border saat fokus */
        box-shadow: 0 0 5px rgba(152, 125, 154, 0.5), /* Efek cahaya pada border saat fokus */
                    0 0 15px rgba(152, 125, 154, 0.3); /* Efek bercahaya tambahan */
    }

    /* Tambahkan efek bercahaya saat hover di dalam input dan textarea */
    input:hover, textarea:hover {
        border-color: #987D9A; /* Warna border saat hover */
        box-shadow: 0 0 5px rgba(152, 125, 154, 0.5), /* Efek cahaya pada border saat hover */
                    0 0 15px rgba(152, 125, 154, 0.3); /* Efek bercahaya tambahan */
    }

    button {
        padding: 10px;
        background-color: #C96868;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s, box-shadow 0.3s; /* Tambahkan transisi untuk efek shadow */
    }

    button:hover {
        background-color: #F3D7CA;
        box-shadow: 0 0 10px rgba(255, 200, 200, 0.5), /* Efek cahaya pada border saat hover */
                    0 0 20px rgba(255, 200, 200, 0.3); /* Efek bercahaya tambahan */
    }

    .error {
        color: #921A40;
        font-size: 0.9em;
        margin-top: -10px;
        margin-bottom: 15px;
    }

    .char-counter {
        font-size: 0.8em;
        color: #666;
        text-align: right;
        margin-bottom: 15px;
    }
</style>

      <form id="note-form">
        <label for="title">Judul</label>
        <input type="text" id="title" placeholder="Masukkan judul..." maxlength="100"> <!-- Updated maxlength -->
        <div class="char-counter" id="title-char-counter">0/100</div> <!-- Updated counter -->
        <div class="error" id="title-error"></div>
        <label for="body">Isi Catatan</label>
        <textarea id="body" placeholder="Masukkan isi catatan..."></textarea>
        <div class="error" id="body-error"></div>
        <button type="submit">Add Note</button>
      </form>
    `;

    const titleInput = this.shadowRoot.querySelector('#title');
    const bodyInput = this.shadowRoot.querySelector('#body');
    const titleError = this.shadowRoot.querySelector('#title-error');
    const titleCharCounter = this.shadowRoot.querySelector('#title-char-counter');
    const bodyError = this.shadowRoot.querySelector('#body-error');

    titleInput.addEventListener('input', () => {
      const titleLength = titleInput.value.length;
      titleCharCounter.textContent = `${titleLength}/100`; // Updated counter logic

      if (titleLength === 0) {
        titleError.textContent = 'Judul tidak boleh kosong.';
      } else if (titleLength > 100) { // Updated limit
        titleError.textContent = 'Judul tidak boleh lebih dari 100 karakter.'; // Updated message
      } else {
        titleError.textContent = '';
      }
    });

    this.shadowRoot
      .querySelector('#note-form')
      .addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = this.shadowRoot.querySelector('#title').value;
        const body = this.shadowRoot.querySelector('#body').value;

        if (title.length > 100) { // Updated limit
          titleError.textContent = 'Judul tidak boleh lebih dari 100 karakter.'; // Updated message
          return;
        }

        if (body.trim() === '') {
          bodyError.textContent = 'Isi catatan tidak boleh kosong.';
          Swal.fire('Error', 'Isi catatan tidak boleh kosong.', 'error');
          return;
        }

        const newNote = await addNoteNew({ title, body });
        if (newNote) {
          this.resetForm();
          document.dispatchEvent(new Event('renderNotes'));
        }
      });
  }

  resetForm() {
    this.shadowRoot.querySelector('#note-form').reset();
    this.shadowRoot.querySelector('#title-char-counter').textContent = '0/100'; // Updated counter reset
    this.shadowRoot.querySelector('#title-error').textContent = '';
    this.shadowRoot.querySelector('#body-error').textContent = '';
  }
}

if (!customElements.get('note-form')) {
  customElements.define('note-form', NoteForm);
}
