import {
  deleteNote,
  unarchiveNoteInApi,
  archiveNoteInApi,
  getMainNotes,
  getArchivedNotes,
} from '../main';
import gsap from 'gsap';

class NoteList extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render([], []);
    this.updateNotes();
    document.addEventListener('renderNotes', () => this.updateNotes()); // Pastikan updateNotes dipanggil setelah event renderNotes
  }

  async updateNotes() {
    const nonArchivedNotes = await getMainNotes();
    const archivedNotes = await getArchivedNotes();
    this.render(nonArchivedNotes, archivedNotes);

    const noteItems = this.shadowRoot.querySelectorAll('note-item');
    
  }

  render(nonArchivedNotes = [], archivedNotes = []) {
    this.shadowRoot.innerHTML = `
      <style>
    .note-section {
        margin-bottom: 20px;
        background: rgba(156, 149, 157, 0.8); /* Latar belakang dengan efek cahaya */
        border: 2px solid transparent; /* Border transparan sebagai dasar */
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* Efek cahaya lebih kuat */
        transition: border-color 0.3s ease, box-shadow 0.3s ease; /* Transisi untuk efek saat hover */
    }

    .note-section:hover {
        border-color: rgba(255, 255, 255, 0.7); /* Mengubah warna border saat hover untuk efek bercahaya */
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.5); /* Efek cahaya saat hover */
    }

    .note-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        padding: 20px;
    }

    .note {
        background: rgba(245, 238, 230, 0.9); /* Latar belakang dengan efek cahaya */
        border: 2px solid transparent; /* Border transparan sebagai dasar */
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Efek cahaya pada catatan */
        transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.3s ease; /* Transisi untuk efek saat hover */
        position: relative;
    }

    .note:hover {
        transform: translateY(-5px);
        box-shadow: 0 0 15px rgba(211, 118, 118, 0.5); /* Efek cahaya saat hover */
        border-color: rgba(255, 255, 255, 0.7); /* Mengubah warna border saat hover untuk efek bercahaya */
    }

    .note-title {
        font-weight: bold;
        font-size: 1.2em;
        margin-bottom: 5px;
        color: #D37676; /* Warna judul catatan */
    }

    .note-body {
        margin: 10px 0;
    }

    .note-section h2 {
        background: #BB9AB1;
        border: 1px solid #D37676;
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Efek cahaya pada judul */
        position: relative;
        color: white;
    }

    .note-created-at {
        font-size: 0.8em;
        color: #aaa;
        position: absolute;
        bottom: 10px;
        right: 10px;
    }

    .note-delete-btn,
    .note-archive-btn,
    .note-unarchive-btn {
        position: absolute;
        top: 10px;
        background-color: #e53935;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 1em;
        right: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Efek cahaya pada tombol */
        transition: background-color 0.3s, box-shadow 0.3s, border-color 0.3s; /* Tambahkan transisi untuk efek border */
        border: 2px solid transparent; /* Border transparan sebagai dasar */
    }

    .note-archive-btn {
        background-color: #f39c12;
        right: 40px;
    }

    .note-unarchive-btn {
        background-color: #2ecc71;
        right: 40px;
    }

    .note-delete-btn:hover {
        background-color: #d32f2f;
        box-shadow: 0 0 10px rgba(227, 74, 74, 0.5); 
        border-color: rgba(255, 255, 255, 0.7); /* Mengubah warna border saat hover untuk efek bercahaya */
    }

    .note-archive-btn:hover {
        background-color: #e67e22;
        box-shadow: 0 0 10px rgba(241, 156, 18, 0.5); 
        border-color: rgba(255, 255, 255, 0.7); 
    }

    .note-unarchive-btn:hover {
        background-color: #27ae60;
        box-shadow: 0 0 10px rgba(46, 204, 113, 0.5); 
        border-color: rgba(255, 255, 255, 0.7); 
    }

    @media (max-width: 600px) {
        .note-container {
            grid-template-columns: 1fr;
        }
    }
</style>

      <div class="note-section">
        <h2>Your Notes</h2>
        <div class="note-container">
          ${
            nonArchivedNotes.length
              ? nonArchivedNotes
                  .map(
                    (note) => `
            <div class="note" data-id="${note.id}">
              <div class="note-title">${note.title}</div>
              <div class="note-body">${note.body}</div>
              <div class="note-created-at">${new Date(note.createdAt).toLocaleString()}</div>
              <button class="note-delete-btn">✕</button>
              <button class="note-archive-btn">⧉</button>
            </div>
          `
                  )
                  .join('')
              : '<p>Tidak ada catatan saat ini.</p>'
          }
        </div>
      </div>
                  
      <div class="note-section">
        <h2>Archived Notes</h2>
        <div class="note-container">
          ${
            archivedNotes.length
              ? archivedNotes
                  .map(
                    (note) => `
            <div class="note" data-id="${note.id}">
              <div class="note-title">${note.title}</div>
              <div class="note-body">${note.body}</div>
              <div class="note-created-at">${new Date(note.createdAt).toLocaleString()}</div>
              <button class="note-delete-btn">✕</button>
              <button class="note-unarchive-btn">↺</button>
            </div>
          `
                  )
                  .join('')
              : '<p>Tidak ada catatan yang diarsipkan.</p>'
          }
        </div>
      </div>
    `;

    this.addDeleteListeners();
    this.addArchiveListeners();
    this.addUnarchiveListeners();
  }

  addDeleteListeners() {
    const deleteButtons = this.shadowRoot.querySelectorAll('.note-delete-btn');
    deleteButtons.forEach((btn) => {
      btn.addEventListener('click', async (event) => {
        try {
          const noteId = event.target.parentElement.getAttribute('data-id');
          const success = await deleteNote(noteId);
          if (success) {
            this.updateNotes();
          }
        } catch (error) {
          console.error('Failed to delete note', error);
        }
      });
    });
  }

  addArchiveListeners() {
    const archiveButtons =
      this.shadowRoot.querySelectorAll('.note-archive-btn');
    archiveButtons.forEach((btn) => {
      btn.addEventListener('click', async (event) => {
        const noteElement = event.target.closest('.note');
        gsap.to(noteElement, {
          duration: 0.5,
          opacity: 0,
          y: -20,
          onComplete: async () => {
            const noteId = noteElement.getAttribute('data-id');
            try {
              const success = await archiveNoteInApi(noteId);
              if (success) {
                console.log('Note archived, updating notes...');
                this.updateNotes(); 
              }
            } catch (error) {
              console.error('Error occurred while archiving note:', error);
            }
          },
        });
      });
    });
  }

  addUnarchiveListeners() {
    const unarchiveButtons = this.shadowRoot.querySelectorAll(
      '.note-unarchive-btn'
    );
    unarchiveButtons.forEach((btn) => {
      btn.addEventListener('click', async (event) => {
        try {
          const noteElement = event.target.closest('.note');
          const noteId = noteElement.getAttribute('data-id');
          const success = await unarchiveNoteInApi(noteId);
          if (success) {
            gsap.to(noteElement, {
              duration: 0.6,
              opacity: 0,
              y: -30,
              ease: 'power2.in',
              onComplete: () => {
                this.updateNotes();
              },
            });
          }
        } catch (error) {
          console.error('Failed to unarchive note', error);
        }
      });
    });
  }
}  

if (!customElements.get('note-list')) {
  customElements.define('note-list', NoteList);
}
