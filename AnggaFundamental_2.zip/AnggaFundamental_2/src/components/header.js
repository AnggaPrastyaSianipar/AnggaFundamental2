class AppBar extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render();
  }

  render() {
    this.shadowRoot.innerHTML = `
        <style>
    :host {
        display: block;
        background: rgba(51, 51, 51, 0.9); /* Latar belakang lebih gelap dengan transparansi */
        color: white;
        padding: 20px;
        text-align: center;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        border: 2px solid transparent; /* Border transparan sebagai dasar */
        border-radius: 8px; /* Menambahkan sudut yang membulat */
        transition: transform 0.3s ease, box-shadow 0.3s ease, border-color 0.3s ease; /* Transisi untuk efek saat hover */
    }

    :host(:hover) {
        transform: translateY(-5px); /* Efek mengangkat saat hover */
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.5); /* Efek cahaya saat hover */
        border-color: rgba(255, 255, 255, 0.7); /* Mengubah warna border saat hover untuk efek bercahaya */
        box-shadow: 0 0 10px rgba(255, 255, 255, 0.5), /* Bayangan luar yang bercahaya */
                    0 0 20px rgba(255, 255, 255, 0.3); /* Efek bercahaya tambahan */
    }
</style>

        <div>
          <h1 style="margin: 0;">MY NOTE'S</h1>
        </div>
      `;
  }
}

if (!customElements.get('app-bar')) {
  customElements.define('app-bar', AppBar);
}
